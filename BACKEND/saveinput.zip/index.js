const AWS = require('aws-sdk');
const { customAlphabet } = require('nanoid');
const nanoid = customAlphabet('1234567890abcdef', 10);

const dynamo = new AWS.DynamoDB.DocumentClient();
const S3_BUCKET = 'fovusfilebucket';

exports.handler = async (event) => {
    const { inputText } = JSON.parse(event.body);
    const id = nanoid();
    const inputFilePath = `${S3_BUCKET}/${id}.txt`;

    // Example assuming the file is already saved in S3
    const params = {
        TableName: 'FileTable',
        Item: {
            id: id,
            input_text: inputText,
            input_file_path: inputFilePath
        }
    };

    try {
        await dynamo.put(params).promise();
        return { 
          statusCode: 200,
          headers: {
              "Access-Control-Allow-Origin": "*",  // Or specifically "http://localhost:3000"
              "Content-Type": "application/json"
          }, 
          body: JSON.stringify({ message: 'Data saved successfully', id }) 
        };
    } catch (err) {
        return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
    }
};
